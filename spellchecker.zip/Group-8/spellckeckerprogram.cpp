#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
using namespace std;

struct ModifiedTrieNode {
    bool isEndOfModifiedWord;
    vector<ModifiedTrieNode*> modifiedChildren;

    ModifiedTrieNode() {
        isEndOfModifiedWord = false;
        modifiedChildren = vector<ModifiedTrieNode*>(26, nullptr);
    }
};

void printInRed(const string& modifiedWord) {
    // Print any modified words in red
    cout << "\033[31m" << modifiedWord << "\033[0m";
}

void insertModifiedWord(ModifiedTrieNode *modifiedRoot, const string &modifiedWord) {
    ModifiedTrieNode *currentNode = modifiedRoot;
    for (char c : modifiedWord) {
        int index = tolower(c) - 'a';
        if (currentNode->modifiedChildren[index] == nullptr) {
            currentNode->modifiedChildren[index] = new ModifiedTrieNode();
        }
        currentNode = currentNode->modifiedChildren[index];
    }
    currentNode->isEndOfModifiedWord = true;
}

bool searchModifiedWord(ModifiedTrieNode *modifiedRoot, string &modifiedWord) {
    ModifiedTrieNode *currentNode = modifiedRoot;
    for (char c : modifiedWord) {
        int index = tolower(c) - 'a';
        if (currentNode->modifiedChildren[index] == nullptr) {
            return false;
        }
        currentNode = currentNode->modifiedChildren[index];
    }
    return currentNode != nullptr && currentNode->isEndOfModifiedWord;
}

vector<string> getModifiedSuggestions(ModifiedTrieNode* modifiedRoot, const string &modifiedWord) {
    vector<string> modifiedSuggestions;

    for (int i = 0; i < modifiedWord.length(); ++i) {
        for (char c = 'a'; c <= 'z'; c++) {
            string suggestion = modifiedWord;
            suggestion[i] = c;
            if (searchModifiedWord(modifiedRoot, suggestion) && suggestion != modifiedWord) {
                modifiedSuggestions.push_back(suggestion);
            }
        }
    }

    for (int i = 0; i <= modifiedWord.length(); ++i) {
        for (char c = 'a'; c <= 'z'; c++) {
            string suggestion = modifiedWord;
            suggestion.insert(i, 1, c);
            if (searchModifiedWord(modifiedRoot, suggestion) && suggestion != modifiedWord) {
                modifiedSuggestions.push_back(suggestion);
            }
        }
    }

    for (int i = 0; i < modifiedWord.length(); ++i) {
        string suggestion = modifiedWord;
        suggestion.erase(i, 1);
        if (searchModifiedWord(modifiedRoot, suggestion) && suggestion != modifiedWord) {
            modifiedSuggestions.push_back(suggestion);
        }
    }

    for (int i = 0; i < modifiedWord.length() - 1; ++i) {
        string suggestion = modifiedWord;
        swap(suggestion[i], suggestion[i + 1]);
        if (searchModifiedWord(modifiedRoot, suggestion) && suggestion != modifiedWord) {
            modifiedSuggestions.push_back(suggestion);
        }
    }

    return modifiedSuggestions;
}

int main() {
    // Load the modified dictionary into memory
    ModifiedTrieNode *modifiedRoot = new ModifiedTrieNode();
    ifstream modifiedDictFile("modifiedDictionary.txt");
    string modifiedWord;
    while (getline(modifiedDictFile, modifiedWord)) {
        insertModifiedWord(modifiedRoot, modifiedWord);
    }
    modifiedDictFile.close();

    // Take a modified sentence from user input
    string modifiedSentence;
    cout << "Enter a sentence to check the spelling: ";
    getline(cin, modifiedSentence);
    for (char &c : modifiedSentence) {
        c = tolower(c);
    }

    // Separate the modified sentence into words
    stringstream modifiedSS(modifiedSentence);
    bool firstModifiedWord = true;
    vector<string> modifiedWords;

    while (modifiedSS >> modifiedWord) {
        if (!searchModifiedWord(modifiedRoot, modifiedWord)) {
            if (!firstModifiedWord) {
                cout << " ";
            }
            printInRed(modifiedWord);
            modifiedWords.push_back(modifiedWord);
        } else {
            if (!firstModifiedWord) {
                cout << " ";
            }
            cout << modifiedWord;
        }
        firstModifiedWord = false;
    }
    cout << endl;

    // Print suggestions for modified words
    for (const string &modifiedWord : modifiedWords) {
        vector<string> modifiedSuggestions = getModifiedSuggestions(modifiedRoot, modifiedWord);
        if (!modifiedSuggestions.empty()) {
            cout << "Suggestions for " << modifiedWord << ": ";
            for (const string &suggestion : modifiedSuggestions) {
                cout << suggestion << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
